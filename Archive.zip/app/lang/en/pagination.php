<?php

return array(

	/*
	|--------------------------------------------------------------------------
	| Pagination Language Lines
	|--------------------------------------------------------------------------
	|
	| The following language lines are used by the paginator library to build
	| the simple pagination links. You are free to change them to anything
	| you want to customize your views to better match your application.
	|
	*/



	'next'     => '<p class="flow-text left">Older</p>',
    'previous' => '<p class="flow-text right">Newer</p>',

);
